package com.example.expt9notification;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ReportActivity extends AppCompatActivity {

    TextView t1,t2;
//    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        t1= findViewById(R.id.headingHere);
        t2 = findViewById(R.id.userData);

        Intent i = getIntent();
        String nameOfUser = i.getStringExtra("name");
        String ageOfUser = i.getStringExtra("age");
        String welcome = "Report Generated for "+nameOfUser+" successfully.";
        String reportData = "Name: "+nameOfUser+"\nAge: "+ageOfUser;

        t1.setText(welcome);
        t2.setText(reportData);
    }
}