package com.example.expt9notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b;
    NotificationManager nm;
    String CHANNEL_ID = "my_channel";
    EditText name,age;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b=findViewById(R.id.buttonForNotification);
        nm=(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        name=findViewById(R.id.nameHere);
        age=findViewById(R.id.ageHere);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                    CharSequence name = "my_channel";
                    String description = "first_channel";
                    int importance = NotificationManager.IMPORTANCE_HIGH;
                    NotificationChannel c = new NotificationChannel(CHANNEL_ID,name,importance);
                    c.setDescription(description);
                    c.enableLights(true);
                    c.setLightColor(Color.RED);
                    c.enableVibration(true);
                    c.setVibrationPattern(new long[]{100,200,300,400,500,400,300,200,100});
                    c.setShowBadge(false);
                    nm.createNotificationChannel(c);
                }
                NotificationCompat.Builder b = new NotificationCompat.Builder(MainActivity.this,CHANNEL_ID);
                b.setSmallIcon(R.drawable.notification_icon);
                b.setContentTitle("Report Generated!");
                b.setContentText("Click Here to get your details.");
                Intent ni = new Intent(MainActivity.this,ReportActivity.class);
                String nameOfUser = name.getText().toString();
                String ageOfUser = age.getText().toString();
                ni.putExtra("name",nameOfUser);
                ni.putExtra("age",ageOfUser);
                PendingIntent p = PendingIntent.getActivity(MainActivity.this,0,ni,PendingIntent.FLAG_UPDATE_CURRENT);
                b.setContentIntent(p);
                nm.notify(0,b.build());
            }
        });
    }
}