package com.example.data;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText nameOfUser;
    ImageButton b;
    TextView resultEntered;
    RadioGroup gender, year;
    RadioButton genderEntered,yearEntered;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameOfUser=findViewById(R.id.name);
        b=findViewById(R.id.nextButton);
        resultEntered=findViewById(R.id.result);
        gender=findViewById(R.id.gendergroup);
        year=findViewById(R.id.yeargroup);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int radioIDGender=gender.getCheckedRadioButtonId();
                genderEntered=findViewById(radioIDGender);
                String genderFinal = genderEntered.getText().toString();

                int radioIDYear=year.getCheckedRadioButtonId();
                yearEntered=findViewById(radioIDYear);
                String yearFinal = yearEntered.getText().toString();

                String nameUser=nameOfUser.getText().toString();
                resultEntered.setVisibility(View.VISIBLE);
                resultEntered.setText("Name: "+nameUser+" \nGender: "+genderFinal+" \nYear: "+yearFinal);
            }
        });

    }
    public void onClick(View v){
        String randomMessage= "Hello World! This is the random message Generated. :)";
        Intent i= new Intent(MainActivity.this,ResultActivity.class);
        i.putExtra("random",randomMessage);
        startActivity(i);
    }
}