package com.example.expt4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.material.timepicker.TimeFormat;

import org.w3c.dom.Text;

import java.sql.Time;
import java.text.DateFormat;
import java.util.Calendar;
import java.text.DateFormat;

public class TimePicker extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {

    int h,m;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_picker);
        Calendar t = Calendar.getInstance();
        h = t.get(Calendar.HOUR);
        m = t.get(Calendar.MINUTE);

        result = findViewById(R.id.importTime);
        TimePickerDialog d = new TimePickerDialog(TimePicker.this, this, h, m, android.text.format.DateFormat.is24HourFormat(TimePicker.this));
        d.show();
    }

    @Override
    public void onTimeSet(android.widget.TimePicker timePicker, int i, int i1) {
        showSetTime(i,i1);
    }
    public void showSetTime(int hour,int minute) {
        result.setText("Hour:"+hour+" Minute:"+minute);
    }
}