package com.example.expt4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;


public class DatePicker extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{

    int a,b,c;
//    int x,y,z;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_picker);
        Calendar t =Calendar.getInstance();
        a=t.get(Calendar.YEAR);
        b=t.get(Calendar.MONTH);
        c=t.get(Calendar.DAY_OF_MONTH);

        result=findViewById(R.id.imports);
        DatePickerDialog d= new DatePickerDialog(DatePicker.this,DatePicker.this,a,b,c);
        d.show();
    }

    @Override
    public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
        showSetDate(year,monthOfYear,dayOfMonth);
    }
    public void showSetDate(int year,int month,int day) {
        result.setText("Year:"+year+" Month:"+month+" Day:"+day);
    }

}