package com.example.expt4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button forDate, forTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        forDate = findViewById(R.id.datePicker);
        forTime = findViewById(R.id.timePicker);

        forDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dateIntent = new Intent(MainActivity.this,DatePicker.class);
                startActivity(dateIntent);
            }
        });

        forTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent timeIntent = new Intent(MainActivity.this,TimePicker.class);
                startActivity(timeIntent);
            }
        });
    }
}