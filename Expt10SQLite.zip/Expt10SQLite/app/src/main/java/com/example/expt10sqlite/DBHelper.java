package com.example.expt10sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Users";
    Context context;

    public DBHelper(Context context){
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table cust "+"(name text,age text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS cust");
        onCreate(sqLiteDatabase);
    }

    public boolean insertRecord(String name, String age){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("age",age);

        db.insert("cust",null,contentValues);
        return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from cust",null);
        return res;
    }

    public boolean updateData (String name2, String age2) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name2);
        contentValues.put("age", age2);
        db.update("cust", contentValues, "name = ? ", new String[] { name2 } );
        return true;
    }

    public Integer deleteData (String name3) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("cust", "name = ? ", new String[] { name3 });
    }

}
