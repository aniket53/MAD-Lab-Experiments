package com.example.expt10sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4;
    EditText name,age;
    String str,str1;
    Boolean r1,r2;
    int r3;
    DBHelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        age = findViewById(R.id.age);
        b1 = findViewById(R.id.insert);
        b2 = findViewById(R.id.update);
        b3 = findViewById(R.id.delete);
        b4 = findViewById(R.id.get);

        mydb= new DBHelper(MainActivity.this);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                str=name.getText().toString();
                str1=age.getText().toString();
                r1=mydb.insertRecord(str,str1);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str2=name.getText().toString();
                String str3=age.getText().toString();
                r2=mydb.updateData(str2,str3);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str4=name.getText().toString();
                r3=mydb.deleteData(str4);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);

            }
        });


    }
}