package com.example.expt10sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    DBHelper mydb;
    ListView obj;
    ArrayList<String> listitem;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mydb = new DBHelper(this);
        obj = (ListView) findViewById(R.id.lv);
        listitem = new ArrayList<>();

        Cursor cursor = mydb.getAllData();

        if (cursor.getCount()==0){
            Toast.makeText(this, "No Data found", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                listitem.add(cursor.getString(0));
                listitem.add(cursor.getString(1));
            }
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listitem);
            obj.setAdapter(adapter);
        }

    }
}