package com.example.exptpartb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class WebViewContainer extends AppCompatActivity {

    Button b;
    WebView wv;
    EditText ed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view_container);

        b=findViewById(R.id.urlButton);
        wv=findViewById(R.id.webView);
        ed=findViewById(R.id.enterURL);

        wv.setWebViewClient(new MyBrowser());
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url =ed.getText().toString();
                wv.getSettings().setLoadsImagesAutomatically(true);
                wv.getSettings().setJavaScriptEnabled(true);
                wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                wv.loadUrl(url);
            }
        });
    }
}

class MyBrowser extends WebViewClient {
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return super.shouldOverrideUrlLoading(view, url);
    }
}