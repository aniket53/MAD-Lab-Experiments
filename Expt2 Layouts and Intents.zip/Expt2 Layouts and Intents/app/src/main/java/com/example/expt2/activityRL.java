package com.example.expt2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activityRL extends AppCompatActivity {

    Button b2;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rl);
        b2=findViewById(R.id.submitRL);
        t1=findViewById(R.id.ok);
        t1.setText(getIntent().getStringExtra("name"));
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(activityRL.this,activityTL.class);
                startActivity(i);
            }
        });
    }
}