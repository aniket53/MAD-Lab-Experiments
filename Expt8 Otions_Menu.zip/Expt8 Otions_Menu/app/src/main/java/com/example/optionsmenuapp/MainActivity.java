package com.example.optionsmenuapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView changes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        changes = findViewById(R.id.selected);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.FY:
                changes.setText("First Year");
                Toast.makeText(getApplicationContext(),"Going to FY",Toast.LENGTH_SHORT).show();
                Intent i1 = new Intent(MainActivity.this,FirstYear.class);
                startActivity(i1);
                return true;

            case R.id.SY:
                changes.setText("Second Year");
                Toast.makeText(getApplicationContext(),"Going to SY",Toast.LENGTH_SHORT).show();
                Intent i2 = new Intent(MainActivity.this,SecondYear.class);
                startActivity(i2);
                return true;

            case R.id.TY:
                changes.setText("Third Year");
                Toast.makeText(getApplicationContext(),"Going to TY",Toast.LENGTH_SHORT).show();
                Intent i3 = new Intent(MainActivity.this,ThirdYear.class);
                startActivity(i3);
                return true;

            case R.id.BY:
                changes.setText("Final Year");
                Toast.makeText(getApplicationContext(),"Going to B.Tech.",Toast.LENGTH_SHORT).show();
                Intent i4 = new Intent(MainActivity.this,FinalYear.class);
                startActivity(i4);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}