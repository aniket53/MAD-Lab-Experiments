package com.example.optionsmenuapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ThirdYear extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_year);
    }
}