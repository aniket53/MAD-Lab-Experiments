package com.example.optionsmenuapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FinalYear extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_year);
    }
}