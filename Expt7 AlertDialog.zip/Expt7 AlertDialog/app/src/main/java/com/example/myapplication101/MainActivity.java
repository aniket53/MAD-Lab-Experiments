package com.example.myapplication101;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText nameOfUser,passOfUser;
    Button login,reset;
    int counter =3;
    AlertDialog.Builder b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameOfUser = findViewById(R.id.username);
        passOfUser = findViewById(R.id.password);
        login = findViewById(R.id.login);
        reset = findViewById(R.id.reset);
        b= new AlertDialog.Builder(MainActivity.this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nameOfUser.getText().toString().equals("admin") && passOfUser.getText().toString().equals("admin")){
                    Toast.makeText(MainActivity.this, "Login Successful :)", Toast.LENGTH_SHORT).show();
                }
                else{
                    counter--;
                    Toast.makeText(MainActivity.this, "Incorrect Credentials Attempts left: "+counter, Toast.LENGTH_SHORT).show();
                    if(counter==0){
                        b.setTitle("Login Attempts Exceeds");
                        b.setMessage("Minimum attempts are 3!! Click on reset button to Try Again");
                        b.setCancelable(false);
                        b.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                        AlertDialog alert = b.create();
                        alert.show();
                        login.setEnabled(false);
                    }
                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                login.setText("");
//                reset.setText("");
                login.setEnabled(true);
                counter=3;
            }
        });
    }
}