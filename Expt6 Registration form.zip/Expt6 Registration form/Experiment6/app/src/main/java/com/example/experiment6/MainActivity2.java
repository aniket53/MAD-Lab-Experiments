package com.example.experiment6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView uname,pass,phone,gender,domain1,domain2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        uname = findViewById(R.id.uname);
        pass=findViewById(R.id.pass);
        phone =findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        domain1=findViewById(R.id.domain1);
        domain2=findViewById(R.id.domain2);

        Intent i = getIntent();
        String username = i.getStringExtra("name").toString();
        String password = i.getStringExtra("password").toString();
        String genders = i.getStringExtra("gender").toString();
        String do1= i.getStringExtra("do1").toString();
        String do2= i.getStringExtra("do2").toString();

        uname.setText(username);
        pass.setText(password);
        gender.setText(genders);
        domain1.setText(do1);
        domain2.setText(do2);

    }
}