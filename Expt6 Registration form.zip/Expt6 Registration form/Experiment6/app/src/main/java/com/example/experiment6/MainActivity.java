package com.example.experiment6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText username, password , phone;
    RadioGroup gendergroup;
    RadioButton radioButton;
    CheckBox cybers,androiddevs;
    Button submit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        phone = findViewById(R.id.phone);
        gendergroup = findViewById(R.id.gendergroup);
        cybers = findViewById(R.id.cyber);
        androiddevs = findViewById(R.id.androiddev);
        submit = findViewById(R.id.submit);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                String uname = username.getText().toString();
                String pass = password.getText().toString();

                int radioID=gendergroup.getCheckedRadioButtonId();
                radioButton=findViewById(radioID);
                String radio = radioButton.getText().toString();

                String domain1 = "";
                String domain2 = "";
                if(cybers.isChecked()){
                    domain1 =cybers.getText().toString();
                }
                if(androiddevs.isChecked()){
                    domain2 =androiddevs.getText().toString();
                }

                i.putExtra("name",uname);
                i.putExtra("password",pass);
                i.putExtra("gender",radio);
                i.putExtra("do1",domain1);
                i.putExtra("do2",domain2);
                Toast.makeText(MainActivity.this, "We are moving to second activity", Toast.LENGTH_SHORT).show();
                startActivity(i);


            }
        });
    }
}