package com.example.fep3;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;

public class Fragment1 extends Fragment {

    Activity referenceActivity;
    View parentHolder;
    EditText name;
    CheckBox ch;
    ImageButton b1;
    public Fragment1() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        referenceActivity = getActivity();
        parentHolder = inflater.inflate(R.layout.fragment_1, container, false);
        name = (EditText) parentHolder.findViewById(R.id.nameOfUser);
        ch = (CheckBox) parentHolder.findViewById(R.id.checkBox);
        b1 = (ImageButton) parentHolder.findViewById(R.id.imageButton);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),FragOnePass.class);
                String names = name.getText().toString();
                String lang = "";
                if (ch.isChecked()){
                    lang = "Java";
                }
                i.putExtra("name",names);
                i.putExtra("lang",lang);
                startActivity(i);
            }
        });
        // Inflate the layout for this fragment
        return parentHolder;
    }
}