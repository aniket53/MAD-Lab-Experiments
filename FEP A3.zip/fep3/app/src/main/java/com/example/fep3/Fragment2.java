package com.example.fep3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Fragment2 extends Fragment {

    Button b1;
    Activity referenceActivity1;
    View parentHolder1;
    public Fragment2() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        referenceActivity1 = getActivity();
        parentHolder1 = inflater.inflate(R.layout.fragment_2, container, false);
        b1 = (Button) parentHolder1.findViewById(R.id.button1);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),FragTwoPass.class);
                startActivity(i);
            }
        });
        // Inflate the layout for this fragment
        return parentHolder1;
    }
}