package com.example.fep3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class FragOnePass extends AppCompatActivity {

    TextView t1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frag_one_pass);

        t1 = findViewById(R.id.result);
        Intent i = getIntent();
        String name = i.getStringExtra("name");
        String lang = i.getStringExtra("lang");
        t1.setText(name+" "+lang);
    }
}